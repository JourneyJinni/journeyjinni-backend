package com.ssafy.mvc.model.dao;

public class BoardDaoImpl {

}
