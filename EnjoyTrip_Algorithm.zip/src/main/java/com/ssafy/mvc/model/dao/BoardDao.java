package com.ssafy.mvc.model.dao;

public interface BoardDao {

}
