package com.ssafy.mvc.model.service;

public class BoardServiceImpl {

}
